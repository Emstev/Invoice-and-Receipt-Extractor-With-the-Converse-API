"""Ledgerline Invoice Reader: the Lambda function behind the web page.

The page sends POST {"filename": "...", "data": "<the file as base64>"} with an x-passcode header. This function:
  1. checks the passcode (stored in the PASSCODE environment variable, never in the page);
  2. refuses files that are not a PDF, PNG or JPEG, or are over 3 MB (cost guard; 3 MB becomes 4 MB as base64);
  3. runs the extractor you built in Task 3 (extract.py: Converse API, then validate() and one retry);
  4. returns {"status": "ok" | "needs_review", "errors": [...], "extraction": {...}, "blocked": false}.
API Gateway adds the CORS headers, so only your CloudFront page can call it from a browser.
"""
import base64
import binascii
import hmac
import json
import os
import re

import boto3
from botocore.config import Config

import extract  # the lab's own extract.py, unchanged

PASSCODE = os.environ["PASSCODE"]
MAX_BYTES = 3_000_000
MODEL = dict(extract.MODELS["nova-lite"], id=os.environ["MODEL_ID"])   # the ID you looked up in Step 2
# Same client settings as extract.py main(): our own retries, so they show in the log.
CLIENT = boto3.client("bedrock-runtime", region_name=extract.REGION,
                      config=Config(retries={"total_max_attempts": 1, "mode": "standard"}, read_timeout=25))
KINDS = {b"%PDF": "pdf", b"\x89PNG": "png", b"\xff\xd8\xff": "jpg"}   # what the first bytes of each type look like


def reply(status, body):
    return {"statusCode": status, "headers": {"content-type": "application/json"}, "body": json.dumps(body)}


def kind_of(data):
    for magic, kind in KINDS.items():
        if data.startswith(magic):
            return kind
    return None


def lambda_handler(event, context):
    # The quick-create $default route also receives the browser's CORS preflight (OPTIONS, no passcode).
    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {"statusCode": 204}
    headers = {k.lower(): v for k, v in (event.get("headers") or {}).items()}
    if not hmac.compare_digest(headers.get("x-passcode", "").encode(), PASSCODE.encode()):
        return reply(401, {"error": "Wrong passcode."})
    raw = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        raw = base64.b64decode(raw).decode("utf-8", "replace")
    try:
        body = json.loads(raw)
        data = base64.b64decode(str(body.get("data", "")), validate=True)
    except (ValueError, AttributeError, binascii.Error):
        return reply(400, {"error": "Send JSON like {\"filename\": \"...\", \"data\": \"<base64>\"}."})
    if not data:
        return reply(400, {"error": "Choose a file first."})
    if len(data) > MAX_BYTES:
        return reply(400, {"error": "Keep the file under 3 MB."})
    kind = kind_of(data)
    if not kind:
        return reply(400, {"error": "Only PDF, PNG and JPEG files can be read."})
    path = extract.Path(f"/tmp/upload.{kind}")          # /tmp is the only folder a function may write to
    path.write_bytes(data)
    try:
        result, meta = extract.process(CLIENT, MODEL, path, "text", [0])
    except Exception as e:  # the log keeps the detail; the page gets a short message
        print("ERROR", repr(e))
        return reply(502, {"error": "The document could not be read just now. Try again in a minute."})
    finally:
        path.unlink(missing_ok=True)
    name = re.sub(r"[^A-Za-z0-9._ -]", "", str(body.get("filename", "")))[:80]
    print("DONE", meta["status"], meta["attempts"], meta["input_tokens"], meta["output_tokens"])
    return reply(200, {"filename": name, "status": meta["status"], "errors": meta["errors"], "extraction": result,
                       "cost_usd": meta["cost_usd"], "blocked": False})
